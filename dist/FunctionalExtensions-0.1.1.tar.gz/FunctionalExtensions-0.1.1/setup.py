from distutils.core import setup

setup(
    name='FunctionalExtensions',
    version='0.1.1',
    author='Chris Thompson',
    author_email='teaforthecat@gmail.com',
    packages=['functional_extensions'],
    url='https://github.com/teaforthecat/FunctionalExtensions.py',
)
